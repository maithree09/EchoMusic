# EchoMusic 🎧

A simple Android music-player UI built with Java and XML-compatible Android project structure.

## Features
- Dark music-library interface with five sample tracks
- Song selection opens a Now Playing screen
- Back navigation to the library
- Play/Pause button toggles its visual state

## Tech
- Java
- Android SDK
- Android Studio / Gradle

## Run
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish.
3. Run the `app` configuration on an emulator or Android phone.

## Scope
This is a Level 1 prototype. The play/pause control is a visual interaction and does not play audio. No API or background playback is implemented.
