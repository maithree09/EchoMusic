package com.example.echomusic;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private final String[] titles = {
        "Midnight City", "Golden Hour", "Ocean Eyes",
        "Dreams", "Afterglow"
    };
    private final String[] artists = {
        "M83", "JVKE", "Billie Eilish", "Fleetwood Mac", "Ed Sheeran"
    };
    private final int[] covers = {
        0xFF6C4AB6, 0xFFE5A84B, 0xFF2B7185, 0xFF34765A, 0xFFB85D76
    };

    private LinearLayout root, homeScreen, songList, playerScreen;
    private TextView playerCover, playerTitle, playerArtist, playButton;
    private int selectedSong = 0;
    private boolean isPlaying = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildLayout();
        showHome();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private void buildLayout() {
        root = column();
        root.setBackgroundColor(Color.rgb(15, 17, 24));
        setContentView(root);

        homeScreen = column();
        homeScreen.setPadding(dp(22), dp(28), dp(22), dp(20));
        root.addView(homeScreen, new LinearLayout.LayoutParams(-1, -1));

        TextView brand = text("E C H O  ♪", 14, 0xFFB8A5FF, true);
        homeScreen.addView(brand);

        TextView heading = text("Find your\nfrequency.", 34, Color.WHITE, true);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = dp(22);
        homeScreen.addView(heading, hp);

        TextView sub = text("A little soundtrack for your world.", 14, 0xFF9EA3B3, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(8);
        homeScreen.addView(sub, sp);

        TextView section = text("YOUR ROTATION", 12, 0xFF9EA3B3, true);
        LinearLayout.LayoutParams secp = new LinearLayout.LayoutParams(-1, -2);
        secp.topMargin = dp(30);
        secp.bottomMargin = dp(12);
        homeScreen.addView(section, secp);

        ScrollView scroll = new ScrollView(this);
        songList = column();
        scroll.addView(songList);
        homeScreen.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        addSongs();

        TextView footer = text("MADE FOR THE MOMENT  •  ECHOMUSIC", 10, 0xFF656B7B, true);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(32));
        homeScreen.addView(footer, fp);

        playerScreen = column();
        playerScreen.setPadding(dp(22), dp(28), dp(22), dp(24));
        playerScreen.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(playerScreen, new LinearLayout.LayoutParams(-1, -1));
        playerScreen.setVisibility(View.GONE);

        Button back = new Button(this);
        back.setText("←   LIBRARY");
        back.setTextColor(0xFFB8A5FF);
        back.setBackgroundColor(Color.TRANSPARENT);
        back.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        playerScreen.addView(back, new LinearLayout.LayoutParams(-1, dp(52)));
        back.setOnClickListener(v -> showHome());

        playerCover = text("♪", 72, Color.WHITE, true);
        playerCover.setGravity(Gravity.CENTER);
        playerCover.setBackground(rounded(0xFF6C4AB6, 24));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, 0, 1);
        cp.topMargin = dp(22);
        cp.bottomMargin = dp(30);
        playerScreen.addView(playerCover, cp);

        TextView now = text("NOW PLAYING", 11, 0xFFB8A5FF, true);
        now.setGravity(Gravity.CENTER);
        playerScreen.addView(now);

        playerTitle = text("", 27, Color.WHITE, true);
        playerTitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.topMargin = dp(10);
        playerScreen.addView(playerTitle, tp);

        playerArtist = text("", 16, 0xFF9EA3B3, false);
        playerArtist.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.topMargin = dp(6);
        playerScreen.addView(playerArtist, ap);

        playButton = text("▶", 25, Color.WHITE, true);
        playButton.setGravity(Gravity.CENTER);
        playButton.setBackground(rounded(0xFF8B72E8, 60));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(76), dp(76));
        bp.gravity = Gravity.CENTER;
        bp.topMargin = dp(32);
        bp.bottomMargin = dp(36);
        playerScreen.addView(playButton, bp);
        playButton.setOnClickListener(v -> {
            isPlaying = !isPlaying;
            playButton.setText(isPlaying ? "Ⅱ" : "▶");
        });
    }

    private void addSongs() {
        String[] emojis = {"🌃", "🌅", "🌊", "🌿", "🌸"};
        for (int i = 0; i < titles.length; i++) {
            final int index = i;
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(10), dp(12), dp(10));
            row.setBackground(rounded(0xFF20232E, 16));
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, dp(78));
            rp.bottomMargin = dp(10);
            songList.addView(row, rp);

            TextView cover = text(emojis[i], 27, Color.WHITE, true);
            cover.setGravity(Gravity.CENTER);
            cover.setBackground(rounded(covers[i], 12));
            row.addView(cover, new LinearLayout.LayoutParams(dp(54), dp(54)));

            LinearLayout labels = column();
            labels.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1);
            lp.leftMargin = dp(14);
            row.addView(labels, lp);
            labels.addView(text(titles[i], 15, Color.WHITE, true));
            TextView artist = text(artists[i], 12, 0xFF9EA3B3, false);
            LinearLayout.LayoutParams artistp = new LinearLayout.LayoutParams(-1, -2);
            artistp.topMargin = dp(5);
            labels.addView(artist, artistp);
            TextView arrow = text("›", 28, 0xFFB8A5FF, false);
            row.addView(arrow);
            row.setOnClickListener(v -> showPlayer(index));
        }
    }

    private void showHome() {
        playerScreen.setVisibility(View.GONE);
        homeScreen.setVisibility(View.VISIBLE);
    }

    private void showPlayer(int index) {
        selectedSong = index;
        isPlaying = false;
        playerTitle.setText(titles[selectedSong]);
        playerArtist.setText(artists[selectedSong]);
        playerCover.setBackground(rounded(covers[selectedSong], 24));
        playerCover.setText(new String[]{"🌃", "🌅", "🌊", "🌿", "🌸"}[selectedSong]);
        playButton.setText("▶");
        homeScreen.setVisibility(View.GONE);
        playerScreen.setVisibility(View.VISIBLE);
    }
}
